import type { SFCWithInstall } from '../mf-utils/types';
import Scrollbar from './src/index.vue';
declare const _Scrollbar: SFCWithInstall<typeof Scrollbar>;
export default _Scrollbar;
