import type { SFCWithInstall } from '../mf-utils/types';
import PageHeader from './src/index.vue';
declare const _PageHeader: SFCWithInstall<typeof PageHeader>;
export default _PageHeader;
