import type { SFCWithInstall } from '../mf-utils/types';
import CheckboxButton from '../mf-checkbox/src/checkbox-button.vue';
declare const _CheckboxButton: SFCWithInstall<typeof CheckboxButton>;
export default _CheckboxButton;
