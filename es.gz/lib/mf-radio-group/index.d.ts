import type { SFCWithInstall } from '../mf-utils/types';
import RadioGroup from '../mf-radio/src/radio-group.vue';
declare const _RadioGroup: SFCWithInstall<typeof RadioGroup>;
export default _RadioGroup;
