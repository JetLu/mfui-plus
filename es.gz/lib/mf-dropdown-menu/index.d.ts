import type { SFCWithInstall } from '../mf-utils/types';
import DropdownMenu from '../mf-dropdown/src/dropdown-menu.vue';
declare const _DropdownMenu: SFCWithInstall<typeof DropdownMenu>;
export default _DropdownMenu;
