import Overlay from './src/index.vue';
export { Overlay };
