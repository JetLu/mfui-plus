import Row from '../mf-col/src/row';
import type { SFCWithInstall } from '../mf-utils/types';
declare const _Row: SFCWithInstall<typeof Row>;
export default _Row;
