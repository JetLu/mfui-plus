import type { SFCWithInstall } from '../mf-utils/types';
import Drawer from './src/index.vue';
declare const _Drawer: SFCWithInstall<typeof Drawer>;
export default _Drawer;
