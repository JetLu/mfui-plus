import CheckTag from './src/index.vue';
import type { SFCWithInstall } from '../mf-utils/types';
declare const _CheckTag: SFCWithInstall<typeof CheckTag>;
export default _CheckTag;
