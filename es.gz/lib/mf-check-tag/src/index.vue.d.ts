declare const _default: import("vue").DefineComponent<{
    checked: BooleanConstructor;
}, {
    onChange: () => void;
}, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, "change"[], "change", import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<{
    checked: boolean;
} & {}>, {
    checked: boolean;
}>;
export default _default;
