import type { SFCWithInstall } from '../mf-utils/types';
import TimelineItem from '../mf-timeline/src/item.vue';
declare const _TimelineItem: SFCWithInstall<typeof TimelineItem>;
export default _TimelineItem;
