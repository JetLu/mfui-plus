import type { SFCWithInstall } from '../mf-utils/types';
import Steps from './src/index.vue';
declare const _Steps: SFCWithInstall<typeof Steps>;
export default _Steps;
