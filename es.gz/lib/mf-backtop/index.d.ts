import type { SFCWithInstall } from '../mf-utils/types';
import Backtop from './src/index.vue';
declare const _Backtop: SFCWithInstall<typeof Backtop>;
export default _Backtop;
