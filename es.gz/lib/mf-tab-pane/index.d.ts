import type { SFCWithInstall } from '../mf-utils/types';
import TabPane from '../mf-tabs/src/tab-pane.vue';
declare const _TabPane: SFCWithInstall<typeof TabPane>;
export default _TabPane;
