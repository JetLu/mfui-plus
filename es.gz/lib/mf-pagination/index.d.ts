import Pagination from './src/index';
import type { SFCWithInstall } from '../mf-utils/types';
declare const _Pagination: SFCWithInstall<typeof Pagination>;
export default _Pagination;
