declare const _default: import("vue").DefineComponent<{
    total: {
        type: NumberConstructor;
        default: number;
    };
}, {
    t: (...args: any[]) => string;
}, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, Record<string, any>, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<{
    total: unknown;
} & {}>, {
    total: unknown;
}>;
export default _default;
