import type { SFCWithInstall } from '../mf-utils/types';
import Affix from './src/index.vue';
declare const _Affix: SFCWithInstall<typeof Affix>;
export default _Affix;
