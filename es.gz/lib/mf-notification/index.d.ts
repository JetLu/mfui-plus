import Notify from './src/notify';
import type { SFCWithInstall } from '../mf-utils/types';
declare const _Notify: SFCWithInstall<typeof Notify>;
export default _Notify;
