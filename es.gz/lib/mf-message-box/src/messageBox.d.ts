import type { ElMessageBox } from './message-box.type';
declare const _default: ElMessageBox;
export default _default;
