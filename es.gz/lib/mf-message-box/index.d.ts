import MessageBox from './src/messageBox';
import type { SFCWithInstall } from '../mf-utils/types';
declare const _MessageBox: SFCWithInstall<typeof MessageBox>;
export default _MessageBox;
