import type { SFCWithInstall } from '../mf-utils/types';
import Step from '../mf-steps/src/item.vue';
declare const _Step: SFCWithInstall<typeof Step>;
export default _Step;
