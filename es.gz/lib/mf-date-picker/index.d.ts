import DatePicker from './src/date-picker';
import type { SFCWithInstall } from '../mf-utils/types';
declare const _DatePicker: SFCWithInstall<typeof DatePicker>;
export default _DatePicker;
