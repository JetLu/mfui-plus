import type { SFCWithInstall } from '../mf-utils/types';
import ButtonGroup from '../mf-button/src/button-group.vue';
declare const _ButtonGroup: SFCWithInstall<typeof ButtonGroup>;
export default _ButtonGroup;
