import type { SFCWithInstall } from '../mf-utils/types';
import DescriptionsItem from '../mf-descriptions/src/description-item';
declare const _DescriptionsItem: SFCWithInstall<typeof DescriptionsItem>;
export default _DescriptionsItem;
