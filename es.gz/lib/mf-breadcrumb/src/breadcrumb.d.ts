export interface IBreadcrumbProps {
    separator: string;
    separatorClass: string;
}
