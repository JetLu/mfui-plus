declare const _default: import("vue").DefineComponent<{
    separator: {
        type: StringConstructor;
        default: string;
    };
    separatorClass: {
        type: StringConstructor;
        default: string;
    };
}, {
    breadcrumb: any;
}, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, Record<string, any>, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<{
    separator: unknown;
    separatorClass: unknown;
} & {}>, {
    separator: unknown;
    separatorClass: unknown;
}>;
export default _default;
