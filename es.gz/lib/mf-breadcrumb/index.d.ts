import type { SFCWithInstall } from '../mf-utils/types';
import Breadcrumb from './src/index.vue';
declare const _Breadcrumb: SFCWithInstall<typeof Breadcrumb>;
export default _Breadcrumb;
