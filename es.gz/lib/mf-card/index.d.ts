import type { SFCWithInstall } from '../mf-utils/types';
import Card from './src/index.vue';
declare const _Card: SFCWithInstall<typeof Card>;
export default _Card;
