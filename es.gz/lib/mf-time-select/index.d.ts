import type { SFCWithInstall } from '../mf-utils/types';
import TimeSelect from './src/time-select.vue';
declare const _TimeSelect: SFCWithInstall<typeof TimeSelect>;
export default _TimeSelect;
