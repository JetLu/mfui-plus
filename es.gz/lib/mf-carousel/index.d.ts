import type { SFCWithInstall } from '../mf-utils/types';
import Carousel from './src/main.vue';
declare const _Carousel: SFCWithInstall<typeof Carousel>;
export default _Carousel;
