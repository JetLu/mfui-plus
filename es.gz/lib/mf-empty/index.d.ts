import Empty from './src/index.vue';
import type { SFCWithInstall } from '../mf-utils/types';
declare const _Empty: SFCWithInstall<typeof Empty>;
export default _Empty;
