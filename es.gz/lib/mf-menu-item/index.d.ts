import type { SFCWithInstall } from '../mf-utils/types';
import MenuItem from '../mf-menu/src/menuItem.vue';
declare const _MenuItem: SFCWithInstall<typeof MenuItem>;
export default _MenuItem;
