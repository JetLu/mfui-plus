import type { SFCWithInstall } from '../mf-utils/types';
import Rate from './src/index.vue';
declare const _Rate: SFCWithInstall<typeof Rate>;
export default _Rate;
