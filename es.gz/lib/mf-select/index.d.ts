import type { SFCWithInstall } from '../mf-utils/types';
import Select from './src/select.vue';
import Option from './src/option.vue';
declare const _Select: SFCWithInstall<typeof Select>;
export { Option };
export default _Select;
