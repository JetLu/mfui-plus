declare const _default: import("vue").DefineComponent<{}, {
    minWidth: import("vue").Ref<string>;
    popperClass: import("vue").ComputedRef<string>;
    isMultiple: import("vue").ComputedRef<boolean>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, import("vue").EmitsOptions, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<{} & {}>, {}>;
export default _default;
