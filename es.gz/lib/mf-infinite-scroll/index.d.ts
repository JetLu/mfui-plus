import InfiniteScroll from './src/index';
import type { SFCWithInstall } from '../mf-utils/types';
declare const _InfiniteScroll: SFCWithInstall<typeof InfiniteScroll>;
export default _InfiniteScroll;
