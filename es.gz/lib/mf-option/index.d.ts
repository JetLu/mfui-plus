import { Option } from '../mf-select';
import type { SFCWithInstall } from '../mf-utils/types';
declare const _Option: SFCWithInstall<typeof Option>;
export default _Option;
