import Skeleton from './src/index.vue';
import type { SFCWithInstall } from '../mf-utils/types';
declare const _Skeleton: SFCWithInstall<typeof Skeleton>;
export default _Skeleton;
