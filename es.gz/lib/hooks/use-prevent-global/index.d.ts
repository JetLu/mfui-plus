import type { Ref } from 'vue';
declare const _default: (indicator: Ref<boolean>, evt: string, cb: (e: Event) => boolean) => void;
export default _default;
