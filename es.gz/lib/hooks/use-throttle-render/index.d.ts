import type { Ref } from 'vue';
export default function (loading: Ref<boolean>, throttle?: number): Ref<boolean>;
