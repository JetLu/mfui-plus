declare const useMigrating: () => {
    getMigratingConfig: () => {
        props: {};
        events: {};
    };
};
export default useMigrating;
