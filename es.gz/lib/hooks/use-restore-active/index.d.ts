import type { Ref } from 'vue';
declare const _default: (toggle: Ref<boolean>, initialFocus?: Ref<HTMLElement>) => void;
export default _default;
