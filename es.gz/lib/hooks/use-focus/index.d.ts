import { Ref } from 'vue';
declare const _default: (el: Ref<HTMLElement>) => {
    focus: () => void;
};
export default _default;
