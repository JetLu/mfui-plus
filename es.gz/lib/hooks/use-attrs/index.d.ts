interface Params {
    excludeListeners?: boolean;
    excludeKeys?: string[];
}
declare const _default: (params?: Params) => import("vue").Ref<{}>;
export default _default;
