import type { Ref } from 'vue';
declare const _default: (trigger: Ref<boolean>) => void;
export default _default;
