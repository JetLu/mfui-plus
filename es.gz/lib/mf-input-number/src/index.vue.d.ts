declare const _default: import("vue").DefineComponent<readonly string[] | Readonly<import("vue").ComponentObjectPropsOptions<Record<string, unknown>>>, {
    input: any;
    displayValue: import("vue").ComputedRef<string | number>;
    handleInput: (value: any) => any;
    handleInputChange: (value: any) => void;
    controlsAtRight: import("vue").ComputedRef<boolean>;
    decrease: () => void;
    increase: () => void;
    inputNumberSize: import("vue").ComputedRef<any>;
    inputNumberDisabled: import("vue").ComputedRef<any>;
    maxDisabled: import("vue").ComputedRef<boolean>;
    minDisabled: import("vue").ComputedRef<boolean>;
}, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("update:modelValue" | "change" | "input" | "blur" | "focus")[], "update:modelValue" | "change" | "input" | "blur" | "focus", import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<{
    [x: number]: unknown;
} & {
    length?: unknown;
    toString?: unknown;
    toLocaleString?: unknown;
    concat?: unknown;
    join?: unknown;
    slice?: unknown;
    indexOf?: unknown;
    lastIndexOf?: unknown;
    every?: unknown;
    some?: unknown;
    forEach?: unknown;
    map?: unknown;
    filter?: unknown;
    reduce?: unknown;
    reduceRight?: unknown;
    find?: unknown;
    findIndex?: unknown;
    entries?: unknown;
    keys?: unknown;
    values?: unknown;
    includes?: unknown;
    flatMap?: unknown;
    flat?: unknown;
}> | Readonly<{} & {
    [x: string]: unknown;
}>, {
    [x: number]: unknown;
} | {}>;
export default _default;
