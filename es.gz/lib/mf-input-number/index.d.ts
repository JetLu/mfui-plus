import type { SFCWithInstall } from '../mf-utils/types';
import InputNumber from './src/index.vue';
declare const _InputNumber: SFCWithInstall<typeof InputNumber>;
export default _InputNumber;
