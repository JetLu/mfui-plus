import type { SFCWithInstall } from '../mf-utils/types';
import DropdownItem from '../mf-dropdown/src/dropdown-item.vue';
declare const _DropdownItem: SFCWithInstall<typeof DropdownItem>;
export default _DropdownItem;
