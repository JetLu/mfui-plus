export declare const rangeArr: (n: any) => number[];
export declare const extractDateFormat: (format: any) => any;
export declare const extractTimeFormat: (format: any) => any;
