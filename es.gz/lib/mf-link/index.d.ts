import type { SFCWithInstall } from '../mf-utils/types';
import Link from './src/index.vue';
declare const _Link: SFCWithInstall<typeof Link>;
export default _Link;
