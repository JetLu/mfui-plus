import type { SFCWithInstall } from '../mf-utils/types';
import ColorPicker from './src/index.vue';
declare const _ColorPicker: SFCWithInstall<typeof ColorPicker>;
export default _ColorPicker;
