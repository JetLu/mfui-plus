import Col from './src/col';
import type { SFCWithInstall } from '../mf-utils/types';
declare const _Col: SFCWithInstall<typeof Col>;
export default _Col;
