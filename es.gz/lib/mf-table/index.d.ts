import type { SFCWithInstall } from '../mf-utils/types';
import Table from './src/table.vue';
declare const _Table: SFCWithInstall<typeof Table>;
export default _Table;
