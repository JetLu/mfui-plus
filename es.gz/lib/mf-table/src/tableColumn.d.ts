import ElTableColumn from './table-column';
export default ElTableColumn;
