import type { SFCWithInstall } from '../mf-utils/types';
import Submenu from '../mf-menu/src/submenu.vue';
declare const _Submenu: SFCWithInstall<typeof Submenu>;
export default _Submenu;
