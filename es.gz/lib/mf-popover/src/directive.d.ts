import type { ObjectDirective } from 'vue';
declare const _default: ObjectDirective<any, any>;
export default _default;
export declare const VPopover = "popover";
