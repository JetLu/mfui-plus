import type { SFCWithInstall } from '../mf-utils/types';
import Popover from './src/index.vue';
declare const _Popover: SFCWithInstall<typeof Popover>;
export default _Popover;
