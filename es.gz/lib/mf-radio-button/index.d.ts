import type { SFCWithInstall } from '../mf-utils/types';
import RadioButton from '../mf-radio/src/radio-button.vue';
declare const _RadioButton: SFCWithInstall<typeof RadioButton>;
export default _RadioButton;
