import TableColumn from '../mf-table/src/tableColumn';
import type { SFCWithInstall } from '../mf-utils/types';
declare const _TableColumn: SFCWithInstall<typeof TableColumn>;
export default _TableColumn;
