declare type TextAreaHeight = {
    height: string;
    minHeight?: string;
};
export default function calcTextareaHeight(targetElement: any, minRows?: number, maxRows?: any): TextAreaHeight;
export {};
