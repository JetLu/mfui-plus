import type { SFCWithInstall } from '../mf-utils/types';
import Input from './src/index.vue';
declare const _Input: SFCWithInstall<typeof Input>;
export default _Input;
