import type { SFCWithInstall } from '../mf-utils/types';
import Timeline from './src/index.vue';
declare const _Timeline: SFCWithInstall<typeof Timeline>;
export default _Timeline;
