declare const _default: (scope: string, m: string) => never;
export default _default;
export declare function warn(scope: string, m: string): void;
