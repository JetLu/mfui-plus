export declare const cubic: (value: number) => number;
export declare const easeInOutCubic: (value: number) => number;
