export declare const isValidWidthUnit: (val: string | number) => boolean;
export declare const isValidComponentSize: (val: string) => boolean;
export declare const isValidDatePickType: (val: string) => boolean;
