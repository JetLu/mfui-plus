declare let rAF: (fn: () => void) => number;
declare let cAF: (handle: number) => void;
export { rAF, cAF, };
