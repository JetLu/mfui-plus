export declare function isKorean(text: string): boolean;
