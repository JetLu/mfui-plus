export default function scrollIntoView(container: HTMLElement, selected: HTMLElement): void;
