export declare function createGlobalNode(id?: string): HTMLDivElement;
export declare function removeGlobalNode(el: HTMLElement): void;
export declare function changeGlobalNodesTarget(el: HTMLElement): void;
