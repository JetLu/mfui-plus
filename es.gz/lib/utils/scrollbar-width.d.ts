export default function (): number;
