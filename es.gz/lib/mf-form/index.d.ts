import type { SFCWithInstall } from '../mf-utils/types';
import Form from './src/form.vue';
declare const _Form: SFCWithInstall<typeof Form>;
export default _Form;
export * from './src/token';
