import type { SFCWithInstall } from '../mf-utils/types';
import CarouselItem from '../mf-carousel/src/item.vue';
declare const _CarouselItem: SFCWithInstall<typeof CarouselItem>;
export default _CarouselItem;
