import type { SFCWithInstall } from '../mf-utils/types';
import Icon from './src/index.vue';
declare const _Icon: SFCWithInstall<typeof Icon>;
export default _Icon;
