import type { SFCWithInstall } from '../mf-utils/types';
import Tabs from './src/tabs.vue';
declare const _Tabs: SFCWithInstall<typeof Tabs>;
export default _Tabs;
