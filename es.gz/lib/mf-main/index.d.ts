import type { SFCWithInstall } from '../mf-utils/types';
import Main from '../mf-container/src/main.vue';
declare const _Main: SFCWithInstall<typeof Main>;
export default _Main;
