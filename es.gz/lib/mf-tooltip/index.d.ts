import Tooltip from './src/index';
import { SFCWithInstall } from '../mf-utils/types';
declare const _Tooltip: SFCWithInstall<typeof Tooltip>;
export default _Tooltip;
