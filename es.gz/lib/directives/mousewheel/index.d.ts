import type { ObjectDirective } from 'vue';
declare const Mousewheel: ObjectDirective;
export default Mousewheel;
