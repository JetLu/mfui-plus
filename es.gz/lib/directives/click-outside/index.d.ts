import type { ObjectDirective } from 'vue';
declare const ClickOutside: ObjectDirective;
export default ClickOutside;
