import type { ObjectDirective } from 'vue';
declare const Resize: ObjectDirective;
export default Resize;
