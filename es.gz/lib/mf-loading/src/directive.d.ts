declare const vLoading: {
    mounted(el: any, binding: any): void;
    updated(el: any, binding: any): void;
    unmounted(el: any): void;
};
export default vLoading;
