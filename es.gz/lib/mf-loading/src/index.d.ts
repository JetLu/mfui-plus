import type { ILoadingInstance, ILoadingOptions } from './loading.type';
declare const Loading: (options?: ILoadingOptions) => ILoadingInstance;
export default Loading;
