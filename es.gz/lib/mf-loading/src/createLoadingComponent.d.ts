import type { ILoadingCreateComponentParams, ILoadingInstance } from './loading.type';
export declare function createLoadingComponent({ options, globalLoadingOption, }: ILoadingCreateComponentParams): ILoadingInstance;
