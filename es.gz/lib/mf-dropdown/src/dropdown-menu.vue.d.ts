declare const _default: import("vue").DefineComponent<{}, {
    size: import("vue").ComputedRef<string>;
    show: () => void;
    hide: () => void;
    innerHide: () => void;
    triggerElm: import("vue").ComputedRef<HTMLButtonElement>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, import("vue").EmitsOptions, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<{} & {}>, {}>;
export default _default;
