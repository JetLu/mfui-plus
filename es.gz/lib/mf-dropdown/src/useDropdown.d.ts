import { IElDropdownInstance } from './dropdown';
export declare const useDropdown: () => {
    ELEMENT: any;
    elDropdown: IElDropdownInstance;
    _elDropdownSize: import("vue").ComputedRef<import("vue").ComputedRef<string>>;
};
export declare const initDropdownDomEvent: (dropdownChildren: any, triggerElm: any, _instance: any) => void;
