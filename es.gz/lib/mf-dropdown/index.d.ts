import type { SFCWithInstall } from '../mf-utils/types';
import Dropdown from './src/dropdown.vue';
declare const _Dropdown: SFCWithInstall<typeof Dropdown>;
export default _Dropdown;
