import type { SFCWithInstall } from '../mf-utils/types';
import Radio from './src/radio.vue';
declare const _Radio: SFCWithInstall<typeof Radio>;
export default _Radio;
