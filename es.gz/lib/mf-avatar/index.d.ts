import type { SFCWithInstall } from '../mf-utils/types';
import Avatar from './src/index.vue';
declare const _Avatar: SFCWithInstall<typeof Avatar>;
export default _Avatar;
