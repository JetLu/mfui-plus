import type { SFCWithInstall } from '../mf-utils/types';
import Transfer from './src/index.vue';
declare const _Transfer: SFCWithInstall<typeof Transfer>;
export default _Transfer;
