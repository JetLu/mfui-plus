import type { SFCWithInstall } from '../mf-utils/types';
import Badge from './src/index.vue';
declare const _Badge: SFCWithInstall<typeof Badge>;
export default _Badge;
