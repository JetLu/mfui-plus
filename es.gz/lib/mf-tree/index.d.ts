import type { SFCWithInstall } from '../mf-utils/types';
import Tree from './src/tree.vue';
declare const _Tree: SFCWithInstall<typeof Tree>;
export default _Tree;
