import type { SFCWithInstall } from '../mf-utils/types';
import Result from './src/index.vue';
declare const _Result: SFCWithInstall<typeof Result>;
export default _Result;
