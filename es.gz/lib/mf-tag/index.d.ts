import type { SFCWithInstall } from '../mf-utils/types';
import Tag from './src/index.vue';
declare const _Tag: SFCWithInstall<typeof Tag>;
export default _Tag;
