declare const _default: import("vue").DefineComponent<{}, {
    on: {
        beforeEnter(el: any): void;
        enter(el: any, done: any): void;
        afterEnter(el: any): void;
        beforeLeave(el: any): void;
        leave(el: any): void;
    };
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, import("vue").EmitsOptions, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<{} & {}>, {}>;
export default _default;
