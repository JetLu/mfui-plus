import type { IMenuProps } from './menu';
export default function useMenuColor(props: IMenuProps): import("vue").ComputedRef<string>;
