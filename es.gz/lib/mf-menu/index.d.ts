import type { SFCWithInstall } from '../mf-utils/types';
import Menu from './src/menu.vue';
declare const _Menu: SFCWithInstall<typeof Menu>;
export default _Menu;
