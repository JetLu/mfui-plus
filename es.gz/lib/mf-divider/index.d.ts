import type { SFCWithInstall } from '../mf-utils/types';
import Divider from './src/index.vue';
declare const _Divider: SFCWithInstall<typeof Divider>;
export default _Divider;
