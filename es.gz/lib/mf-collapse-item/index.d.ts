import type { SFCWithInstall } from '../mf-utils/types';
import CollapseItem from '../mf-collapse/src/collapse-item.vue';
declare const _CollapseItem: SFCWithInstall<typeof CollapseItem>;
export default _CollapseItem;
