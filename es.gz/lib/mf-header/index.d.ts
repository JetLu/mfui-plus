import type { SFCWithInstall } from '../mf-utils/types';
import Header from '../mf-container/src/header.vue';
declare const _Header: SFCWithInstall<typeof Header>;
export default _Header;
