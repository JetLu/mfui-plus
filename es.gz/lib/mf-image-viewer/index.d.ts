import type { SFCWithInstall } from '../mf-utils/types';
import ImageViewer from './src/index.vue';
declare const _ImageViewer: SFCWithInstall<typeof ImageViewer>;
export default _ImageViewer;
