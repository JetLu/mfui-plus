import { InjectionKey } from 'vue';
import { IDescriptionsInject } from './descriptions.type';
export declare const elDescriptionsKey: InjectionKey<IDescriptionsInject>;
