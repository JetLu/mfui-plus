import type { SFCWithInstall } from '../mf-utils/types';
import Descriptions from './src/index.vue';
declare const _Descriptions: SFCWithInstall<typeof Descriptions>;
export default _Descriptions;
