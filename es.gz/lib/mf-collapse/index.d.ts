import type { SFCWithInstall } from '../mf-utils/types';
import Collapse from './src/collapse.vue';
declare const _Collapse: SFCWithInstall<typeof Collapse>;
export default _Collapse;
