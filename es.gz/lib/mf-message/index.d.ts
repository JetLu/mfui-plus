import Message from './src/message';
import type { SFCWithInstall } from '../mf-utils/types';
declare const _Message: SFCWithInstall<typeof Message>;
export default _Message;
