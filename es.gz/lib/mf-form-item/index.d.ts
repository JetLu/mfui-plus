import type { SFCWithInstall } from '../mf-utils/types';
import FormItem from '../mf-form/src/form-item.vue';
declare const _FormItem: SFCWithInstall<typeof FormItem>;
export default _FormItem;
