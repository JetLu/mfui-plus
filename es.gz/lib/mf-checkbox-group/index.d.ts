import type { SFCWithInstall } from '../mf-utils/types';
import CheckboxGroup from '../mf-checkbox/src/checkbox-group.vue';
declare const _CheckboxGroup: SFCWithInstall<typeof CheckboxGroup>;
export default _CheckboxGroup;
