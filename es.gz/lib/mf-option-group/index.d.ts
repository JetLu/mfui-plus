import type { SFCWithInstall } from '../mf-utils/types';
import OptionGroup from '../mf-select/src/option-group.vue';
declare const _OptionGroup: SFCWithInstall<typeof OptionGroup>;
export default _OptionGroup;
