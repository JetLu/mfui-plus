import type { SFCWithInstall } from '../mf-utils/types';
import Checkbox from './src/checkbox.vue';
declare const _Checkbox: SFCWithInstall<typeof Checkbox>;
export default _Checkbox;
