import type { SFCWithInstall } from '../mf-utils/types';
import Footer from '../mf-container/src/footer.vue';
declare const _Footer: SFCWithInstall<typeof Footer>;
export default _Footer;
