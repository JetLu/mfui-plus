import type { SFCWithInstall } from '../mf-utils/types';
import Image from './src/index.vue';
declare const _Image: SFCWithInstall<typeof Image>;
export default _Image;
