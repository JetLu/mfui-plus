import type { SFCWithInstall } from '../mf-utils/types';
import Progress from './src/index.vue';
declare const _Progress: SFCWithInstall<typeof Progress>;
export default _Progress;
