import type { SFCWithInstall } from '../mf-utils/types';
import BreadcrumbItem from '../mf-breadcrumb/src/item.vue';
declare const _BreadcrumbItem: SFCWithInstall<typeof BreadcrumbItem>;
export default _BreadcrumbItem;
