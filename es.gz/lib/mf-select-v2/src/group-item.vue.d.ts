declare const _default: import("vue").DefineComponent<{
    item: {
        type: ObjectConstructor;
        required: true;
    };
    style: ObjectConstructor;
    height: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, Record<string, any>, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<{
    item: Record<string, any>;
} & {
    style?: Record<string, any>;
    height?: unknown;
}>, {}>;
export default _default;
