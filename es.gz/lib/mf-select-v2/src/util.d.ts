import type { Option, OptionGroup } from './select.types';
export declare const flattenOptions: (options: Array<Option | OptionGroup>) => any[];
