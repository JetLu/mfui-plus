import type { SFCWithInstall } from '../mf-utils/types';
import Autocomplete from './src/index.vue';
declare const _Autocomplete: SFCWithInstall<typeof Autocomplete>;
export default _Autocomplete;
