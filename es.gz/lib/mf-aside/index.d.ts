import type { SFCWithInstall } from '../mf-utils/types';
import Aside from '../mf-container/src/aside.vue';
declare const _Aside: SFCWithInstall<typeof Aside>;
export default _Aside;
