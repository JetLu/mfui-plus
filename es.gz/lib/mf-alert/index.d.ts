import type { SFCWithInstall } from '../mf-utils/types';
import Alert from './src/index.vue';
declare const _Alert: SFCWithInstall<typeof Alert>;
export default _Alert;
