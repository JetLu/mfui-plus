import type { SFCWithInstall } from '../mf-utils/types';
import Popconfirm from './src/index.vue';
declare const _Popconfirm: SFCWithInstall<typeof Popconfirm>;
export default _Popconfirm;
