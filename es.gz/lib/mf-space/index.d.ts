import Space from './src/index';
import type { SFCWithInstall } from '../mf-utils/types';
declare const _Space: SFCWithInstall<typeof Space>;
export default _Space;
