import type { SFCWithInstall } from '../mf-utils/types';
import Switch from './src/index.vue';
declare const _Switch: SFCWithInstall<typeof Switch>;
export default _Switch;
