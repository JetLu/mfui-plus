declare const _default: import("vue").DefineComponent<{
    disabled: {
        type: BooleanConstructor;
        default: boolean;
    };
}, {
    dragover: import("vue").Ref<boolean>;
    onDrop: (e: DragEvent) => void;
    onDragover: () => void;
}, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, "file"[], "file", import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<{
    disabled: boolean;
} & {}>, {
    disabled: boolean;
}>;
export default _default;
