import type { ElUploadRequestOptions } from './upload.type';
export default function upload(option: ElUploadRequestOptions): XMLHttpRequest;
