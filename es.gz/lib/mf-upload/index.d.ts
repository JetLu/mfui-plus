import type { SFCWithInstall } from '../mf-utils/types';
import Upload from './src/index.vue';
declare const _Upload: SFCWithInstall<typeof Upload>;
export default _Upload;
