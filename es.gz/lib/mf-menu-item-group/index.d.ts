import type { SFCWithInstall } from '../mf-utils/types';
import MenuItemGroup from '../mf-menu/src/menuItemGroup.vue';
declare const _MenuItemGroup: SFCWithInstall<typeof MenuItemGroup>;
export default _MenuItemGroup;
