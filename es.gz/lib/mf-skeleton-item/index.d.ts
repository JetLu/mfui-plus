import SkeletonItem from './src/index.vue';
import type { SFCWithInstall } from '../mf-utils/types';
declare const _SkeletonItem: SFCWithInstall<typeof SkeletonItem>;
export default _SkeletonItem;
