import type { SFCWithInstall } from '../mf-utils/types';
import Button from './src/button.vue';
declare const _Button: SFCWithInstall<typeof Button>;
export default _Button;
