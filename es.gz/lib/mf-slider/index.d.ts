import type { SFCWithInstall } from '../mf-utils/types';
import Slider from './src/index.vue';
declare const _Slider: SFCWithInstall<typeof Slider>;
export default _Slider;
