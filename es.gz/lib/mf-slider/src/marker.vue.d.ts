import { PropType } from 'vue';
declare const _default: import("vue").DefineComponent<{
    mark: {
        type: PropType<string | Record<string, unknown>>;
        default: () => any;
    };
}, {
    label: import("vue").ComputedRef<any>;
}, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, Record<string, any>, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<{} & {
    mark?: unknown;
}>, {
    mark: unknown;
}>;
export default _default;
