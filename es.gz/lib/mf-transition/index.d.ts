import { App } from 'vue';
import ElCollapseTransition from './collapse-transition/index.vue';
declare const _default: (app: App) => void;
export default _default;
export { ElCollapseTransition };
