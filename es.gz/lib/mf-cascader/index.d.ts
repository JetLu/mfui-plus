import type { SFCWithInstall } from '../mf-utils/types';
import Cascader from './src/index.vue';
declare const _Cascader: SFCWithInstall<typeof Cascader>;
export default _Cascader;
