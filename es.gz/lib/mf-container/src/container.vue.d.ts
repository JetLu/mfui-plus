declare const _default: import("vue").DefineComponent<{
    direction: {
        type: StringConstructor;
        default: string;
    };
}, {
    isVertical: import("vue").ComputedRef<boolean>;
}, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, Record<string, any>, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<{
    direction: unknown;
} & {}>, {
    direction: unknown;
}>;
export default _default;
