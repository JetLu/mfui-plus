import type { SFCWithInstall } from '../mf-utils/types';
import Container from './src/container.vue';
declare const _Container: SFCWithInstall<typeof Container>;
export default _Container;
