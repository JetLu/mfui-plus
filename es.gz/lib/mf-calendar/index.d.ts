import type { SFCWithInstall } from '../mf-utils/types';
import Calendar from './src/index.vue';
declare const _Calendar: SFCWithInstall<typeof Calendar>;
export default _Calendar;
