import type { SFCWithInstall } from '../mf-utils/types';
import CollapseTransition from '../transition/collapse-transition/index.vue';
declare const _CollapseTransition: SFCWithInstall<typeof CollapseTransition>;
export default _CollapseTransition;
